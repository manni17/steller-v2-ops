
# Rate

## Structure

`Rate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CurrencyCode` | `string` | Required | - |
| `MValue` | `double` | Required | - |

## Example (as JSON)

```json
{
  "currencyCode": "INR",
  "value": 22.718078
}
```

