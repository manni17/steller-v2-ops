
# Product 3

## Structure

`Product3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Sku` | `string` | Required | - |
| `Quantity` | `int` | Required | - |
| `MValue` | `int` | Required | - |

## Example (as JSON)

```json
{
  "Sku": "TBRAND-AE",
  "Quantity": 1,
  "Value": 10
}
```

