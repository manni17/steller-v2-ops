
# Category

## Structure

`Category`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `Description` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "id": 2,
  "name": "Gaming",
  "description": "description2"
}
```

