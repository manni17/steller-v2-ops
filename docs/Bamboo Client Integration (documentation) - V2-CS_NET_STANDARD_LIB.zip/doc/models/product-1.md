
# Product 1

## Structure

`Product1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `int` | Required | - |
| `Quantity` | `int` | Required | - |
| `MValue` | `int` | Required | - |

## Example (as JSON)

```json
{
  "ProductId": 0,
  "Quantity": 1,
  "Value": 1
}
```

