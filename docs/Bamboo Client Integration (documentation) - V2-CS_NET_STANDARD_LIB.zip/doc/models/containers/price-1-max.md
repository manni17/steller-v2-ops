
# Price 1 Max

## Class Name

`Price1Max`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | Price1Max.FromNumber(int number) |
| `double` | Price1Max.FromPrecision(double precision) |

