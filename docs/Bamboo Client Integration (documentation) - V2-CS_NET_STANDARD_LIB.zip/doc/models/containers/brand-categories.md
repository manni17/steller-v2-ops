
# Brand Categories

## Class Name

`BrandCategories`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Category`](../../../doc/models/category.md) | BrandCategories.FromCategory(Category category) |
| `string` | BrandCategories.FromString(string mString) |

