
# Price 1 Min

## Class Name

`Price1Min`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | Price1Min.FromNumber(int number) |
| `double` | Price1Min.FromPrecision(double precision) |

