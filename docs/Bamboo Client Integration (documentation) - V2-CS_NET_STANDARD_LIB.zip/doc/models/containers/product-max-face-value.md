
# Product Max Face Value

## Class Name

`ProductMaxFaceValue`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | ProductMaxFaceValue.FromNumber(int number) |
| `double` | ProductMaxFaceValue.FromPrecision(double precision) |

