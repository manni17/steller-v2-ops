
# Account Balance

## Class Name

`AccountBalance`

## Cases

| Type | Factory Method |
|  --- | --- |
| `double` | AccountBalance.FromPrecision(double precision) |
| `int` | AccountBalance.FromNumber(int number) |

