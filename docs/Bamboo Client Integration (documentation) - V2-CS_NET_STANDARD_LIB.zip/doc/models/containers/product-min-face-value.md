
# Product Min Face Value

## Class Name

`ProductMinFaceValue`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | ProductMinFaceValue.FromNumber(int number) |
| `double` | ProductMinFaceValue.FromPrecision(double precision) |

