
# Price Min

## Class Name

`PriceMin`

## Cases

| Type | Factory Method |
|  --- | --- |
| `double` | PriceMin.FromPrecision(double precision) |
| `int` | PriceMin.FromNumber(int number) |

