
# Item 2 Face Values

## Class Name

`Item2FaceValues`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`FaceValue`](../../../doc/models/face-value.md) | Item2FaceValues.FromFaceValue(FaceValue faceValue) |
| `string` | Item2FaceValues.FromString(string mString) |

