
# Item 2 Categories

## Class Name

`Item2Categories`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | Item2Categories.FromNumber(int number) |
| `string` | Item2Categories.FromString(string mString) |

