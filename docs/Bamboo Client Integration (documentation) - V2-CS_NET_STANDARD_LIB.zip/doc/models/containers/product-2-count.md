
# Product 2 Count

## Class Name

`Product2Count`

## Cases

| Type | Factory Method |
|  --- | --- |
| `string` | Product2Count.FromString(string mString) |
| `int` | Product2Count.FromNumber(int number) |

