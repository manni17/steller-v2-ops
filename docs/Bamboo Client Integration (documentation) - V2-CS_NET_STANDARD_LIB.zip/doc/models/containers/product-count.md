
# Product Count

## Class Name

`ProductCount`

## Cases

| Type | Factory Method |
|  --- | --- |
| `string` | ProductCount.FromString(string mString) |
| `int` | ProductCount.FromNumber(int number) |

