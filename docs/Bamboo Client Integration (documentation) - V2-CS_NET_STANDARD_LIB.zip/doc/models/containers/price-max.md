
# Price Max

## Class Name

`PriceMax`

## Cases

| Type | Factory Method |
|  --- | --- |
| `double` | PriceMax.FromPrecision(double precision) |
| `int` | PriceMax.FromNumber(int number) |

