
# Item 1 Categories

## Class Name

`Item1Categories`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Category`](../../../doc/models/category.md) | Item1Categories.FromCategory(Category category) |
| `string` | Item1Categories.FromString(string mString) |

