
# Denomination

## Structure

`Denomination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MValue` | `int` | Required | - |
| `CurrencyCode` | `string` | Required | - |

## Example (as JSON)

```json
{
  "value": 10,
  "currencyCode": "USD"
}
```

