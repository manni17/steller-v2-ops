
# Face Value

## Structure

`FaceValue`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Min` | `int?` | Optional | - |
| `Max` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "min": 1,
  "max": 1
}
```

