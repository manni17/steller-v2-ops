
# Category 3

## Structure

`Category3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | - |
| `Name` | `string` | Required | - |
| `Description` | `string` | Required | - |

## Example (as JSON)

```json
{
  "id": 1,
  "name": "Entertainment",
  "description": ""
}
```

