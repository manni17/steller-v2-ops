
# Available Balance

## Structure

`AvailableBalance`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MValue` | `double` | Required | - |
| `CurrencyCode` | `string` | Required | - |

## Example (as JSON)

```json
{
  "value": 100828.4848,
  "currencyCode": "USD"
}
```

