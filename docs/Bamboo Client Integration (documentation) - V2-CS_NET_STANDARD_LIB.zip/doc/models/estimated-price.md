
# Estimated Price

## Structure

`EstimatedPrice`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MValue` | `double` | Required | - |
| `CurrencyCode` | `string` | Required | - |

## Example (as JSON)

```json
{
  "value": 9.47,
  "currencyCode": "USD"
}
```

